import pygame
import sys
pygame.init()

# Set up the display
screen_width = 600
screen_height = 400
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Level 1 Completed")

# Set up the font
font = pygame.font.SysFont(None, 50)

# Set up the message box
message_rect = pygame.Rect(50, 50, 500, 300)

# Set up the colors
white = (255, 255, 255)
black = (0, 0, 0)
gray = (128, 128, 128)

# Set up the game loop
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Fill the background
    screen.fill(white)

    # Draw the message box
    pygame.draw.rect(screen, black, message_rect, 2)
    pygame.draw.rect(screen, gray, message_rect)

    # Draw the message text
    message_text = font.render("Level 1 Completed!", True, black)
    screen.blit(message_text, (message_rect.x + message_rect.width // 2 - message_text.get_width() // 2,
                               message_rect.y + message_rect.height // 2 - message_text.get_height() // 2))

    pygame.display.update()
